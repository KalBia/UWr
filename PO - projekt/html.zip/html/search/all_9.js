var searchData=
[
  ['make_5faction_0',['make_action',['../class_area.html#a6323cfa5bf7ddf3c31ea0be3811e4b1c',1,'Area']]]
];
