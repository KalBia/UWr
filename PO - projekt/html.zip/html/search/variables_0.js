var searchData=
[
  ['description_0',['description',['../class_door.html#a96c6909186051c511d56e142ec9e8630',1,'Door::description'],['../class_key.html#a95ee24bc47b38869f15f6235236f8350',1,'Key::description']]]
];
