var searchData=
[
  ['check_5fanswer_5fto_5friddle_0',['check_answer_to_riddle',['../class_door___riddle.html#a090cbfff5ef4ea99924fc04ddf39d365',1,'Door_Riddle']]],
  ['check_5finventory_1',['check_inventory',['../class_game.html#a113769826fd5d6158bb8b31a006cfbfc',1,'Game']]],
  ['check_5fscul_2',['check_scul',['../class_area.html#a7df13f299ffe528c1f337a24c5fb9b39',1,'Area']]]
];
